import React, { useState } from 'react';
import { Outlet } from 'react-router-dom';
import Navbar from '../components/Navbar';

const MainLayout = () => {
    const [active, setActive] = useState("home");
    
    return (
        <div>
            <Navbar active={active} setActive={setActive} />
            <Outlet />
        </div>
    );
};

export default MainLayout;