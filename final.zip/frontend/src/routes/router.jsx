import React from "react";
import { createBrowserRouter } from "react-router-dom";
import MainLayout from "../layouts/MainLayout";
import HomePage from "../pages/HomePage/Homepage";
import TaskList from "../pages/TaskList/TaskList";
import AddTask from "../pages/AddTask/AddTask";
import TaskDetails from "../pages/TaskDetails/TaskDetails";
import EditTask from "../pages/EditTask/EditTask";

const router = createBrowserRouter([
  {
    path: "/",
    element: <MainLayout></MainLayout>,
    children: [
      {
        path: "/",
        element: <HomePage></HomePage>,
      },
      {
        path: "/tasks",
        element: <TaskList></TaskList>,
      },
      {
        path: "/add-task",
        element: <AddTask></AddTask>,
      },
      {
        path: "/task/:id",
        element: <TaskDetails></TaskDetails>,
      },
      {
        path: "/edit/:id",
        element: <EditTask></EditTask>,
      },
    ],
  },
]);

export default router;
