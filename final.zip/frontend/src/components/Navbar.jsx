import React from 'react';
import { useNavigate } from 'react-router-dom';


const NAV_ITEMS = [
  {
    id: "home",
    label: "Home",
    url: "/",
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4">
        <path d="M3 9.5L12 3l9 6.5V20a1 1 0 01-1 1H4a1 1 0 01-1-1V9.5z" />
        <path d="M9 21V12h6v9" />
      </svg>
    ),
  },
  {
    id: "add-task",
    label: "Add Task",
    url: "/add-task",
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4">
        <circle cx="12" cy="12" r="9" />
        <line x1="12" y1="8" x2="12" y2="16" />
        <line x1="8" y1="12" x2="16" y2="12" />
      </svg>
    ),
  },
  {
    id: "task-list",
    label: "Task List",
    url: "/tasks",
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4">
        <rect x="3" y="5" width="18" height="14" rx="2" />
        <line x1="7" y1="9" x2="17" y2="9" />
        <line x1="7" y1="13" x2="13" y2="13" />
        <line x1="7" y1="17" x2="11" y2="17" />
      </svg>
    ),
  },
];

const Navbar = ({ active, setActive }) => {
    const navigate = useNavigate();

    const handleNavClick = (item) => {
        setActive(item.id);
        if (item.url) {
            navigate(item.url);
        }
    };

    return (
        <nav className="w-full bg-[#0f1117] border-b border-white/10 px-6 py-0 flex items-center justify-between h-16 sticky top-0 z-50">
            {/* Logo */}
            <div className="flex items-center gap-3 min-w-[180px]">
                <div className="w-8 h-8 bg-orange-500 rounded-sm flex items-center justify-center flex-shrink-0">
                    <svg viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth={2.2} strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4">
                        <rect x="1" y="3" width="15" height="13" rx="1" />
                        <path d="M16 8h4l3 5v3h-7V8z" />
                        <circle cx="5.5" cy="18.5" r="2.5" />
                        <circle cx="18.5" cy="18.5" r="2.5" />
                    </svg>
                </div>
                <span className="text-white font-semibold text-sm tracking-wide leading-tight">
                    DeliveryTask
                </span>
            </div>

            {/* Nav Buttons */}
            <div className="flex items-center gap-1">
                {NAV_ITEMS.map((item) => (
                    <button
                        key={item.id}
                        onClick={() => handleNavClick(item)}
                        className={`flex items-center gap-2 px-4 py-2 rounded-sm text-sm font-medium transition-all duration-200 cursor-pointer
              ${active === item.id
                                ? "bg-orange-500 text-white"
                                : "text-white/60 hover:text-white hover:bg-white/8"
                            }`}
                    >
                        {item.icon}
                        <span className="tracking-wide">{item.label}</span>
                    </button>
                ))}
            </div>

            {/* Profile */}
            <div className="flex items-center gap-3 min-w-[180px] justify-end">
                <button className="flex items-center gap-2.5 px-3 py-1.5 rounded-sm border border-white/15 hover:border-white/30 hover:bg-white/5 transition-all duration-200 cursor-pointer">
                    <div className="w-7 h-7 rounded-full bg-gradient-to-br from-orange-400 to-orange-600 flex items-center justify-center text-xs font-bold text-white">
                        RK
                    </div>
                    <span className="text-white/80 text-sm font-medium">Rafiq K.</span>
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} className="w-3.5 h-3.5 text-white/40">
                        <polyline points="6 9 12 15 18 9" />
                    </svg>
                </button>
            </div>
        </nav>
    );
};

export default Navbar;