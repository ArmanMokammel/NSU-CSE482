import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const PAGE_SIZE = 8;

const PRIORITY_STYLES = {
    High: "text-red-400 bg-red-400/10 border-red-400/25",
    Medium: "text-amber-400 bg-amber-400/10 border-amber-400/25",
    Low: "text-emerald-400 bg-emerald-400/10 border-emerald-400/25",
};

const STATUS_STYLES = {
    "In Progress": "text-sky-400 bg-sky-400/10 border-sky-400/25",
    Pending: "text-orange-400 bg-orange-400/10 border-orange-400/25",
    Completed: "text-emerald-400 bg-emerald-400/10 border-emerald-400/25",
};

const STATUS_DOT = {
    "In Progress": "bg-sky-400",
    Pending: "bg-orange-400",
    Completed: "bg-emerald-400",
};

// Icons
const IconView = () => (
    <svg
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth={1.8}
        strokeLinecap="round"
        strokeLinejoin="round"
        className="w-4 h-4"
    >
        <path d="M1 12S5 4 12 4s11 8 11 8-4 8-11 8S1 12 1 12z" />
        <circle cx="12" cy="12" r="3" />
    </svg>
);

const IconEdit = () => (
    <svg
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth={1.8}
        strokeLinecap="round"
        strokeLinejoin="round"
        className="w-4 h-4"
    >
        <path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7" />
        <path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z" />
    </svg>
);

const IconDelete = () => (
    <svg
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth={1.8}
        strokeLinecap="round"
        strokeLinejoin="round"
        className="w-4 h-4"
    >
        <polyline points="3 6 5 6 21 6" />
        <path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6" />
        <path d="M10 11v6M14 11v6" />
        <path d="M9 6V4a1 1 0 011-1h4a1 1 0 011 1v2" />
    </svg>
);

const IconDeleteAll = () => (
    <svg
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth={1.8}
        strokeLinecap="round"
        strokeLinejoin="round"
        className="w-4 h-4"
    >
        <path d="M3 6h18M8 6V4h8v2M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6" />
        <line x1="10" y1="11" x2="10" y2="17" />
        <line x1="14" y1="11" x2="14" y2="17" />
        <path d="M3 10l1-4M21 10l-1-4" />
    </svg>
);

const IconChevronLeft = () => (
    <svg
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth={2}
        strokeLinecap="round"
        strokeLinejoin="round"
        className="w-4 h-4"
    >
        <polyline points="15 18 9 12 15 6" />
    </svg>
);

const IconChevronRight = () => (
    <svg
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth={2}
        strokeLinecap="round"
        strokeLinejoin="round"
        className="w-4 h-4"
    >
        <polyline points="9 18 15 12 9 6" />
    </svg>
);

// Confirm Modal
function ConfirmModal({ message, onConfirm, onCancel }) {
    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm">
            <div className="bg-[#1a1d27] border border-white/10 rounded-sm w-full max-w-sm mx-4 p-6 shadow-2xl">
                <div className="flex items-start gap-4 mb-6">
                    <div className="w-10 h-10 bg-red-500/15 border border-red-500/25 rounded-sm flex items-center justify-center flex-shrink-0 text-red-400 mt-0.5">
                        <IconDeleteAll />
                    </div>

                    <div>
                        <p className="text-white font-semibold text-sm mb-1">
                            Confirm Deletion
                        </p>

                        <p className="text-white/50 text-sm leading-relaxed">
                            {message}
                        </p>
                    </div>
                </div>

                <div className="flex gap-2 justify-end">
                    <button
                        onClick={onCancel}
                        className="px-4 py-2 text-sm text-white/60 hover:text-white border border-white/10 hover:border-white/25 rounded-sm transition-all cursor-pointer"
                    >
                        Cancel
                    </button>

                    <button
                        onClick={onConfirm}
                        className="px-4 py-2 text-sm font-semibold bg-red-500 hover:bg-red-400 text-white rounded-sm transition-all cursor-pointer"
                    >
                        Delete
                    </button>
                </div>
            </div>
        </div>
    );
}

const TaskList = () => {
    const navigate = useNavigate();

    const [tasks, setTasks] = useState([]);
    const [page, setPage] = useState(1);
    const [modal, setModal] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");

    // Fetch Tasks
    useEffect(() => {
        fetchTasks();
    }, []);

    const fetchTasks = async () => {
        try {
            setLoading(true);

            const response = await axios.get(
                "http://localhost:5000/api/tasks"
            );

            setTasks(response.data);
            setError("");
        } catch (err) {
            console.error("Error fetching tasks:", err);
            setError("Failed to load tasks");
        } finally {
            setLoading(false);
        }
    };

    const totalPages = Math.max(
        1,
        Math.ceil(tasks.length / PAGE_SIZE)
    );

    const safePage = Math.min(page, totalPages);

    const startIdx = (safePage - 1) * PAGE_SIZE;

    const endIdx = Math.min(
        startIdx + PAGE_SIZE,
        tasks.length
    );

    const pageTasks = tasks.slice(startIdx, endIdx);

    // Delete One
    const handleDeleteOne = async (id) => {
        try {
            await axios.delete(
                `http://localhost:5000/api/tasks/${id}`
            );

            setTasks((prev) =>
                prev.filter((t) => t._id !== id)
            );

            setModal(null);

            const newTotal = tasks.length - 1;

            const newTotalPages = Math.max(
                1,
                Math.ceil(newTotal / PAGE_SIZE)
            );

            if (safePage > newTotalPages) {
                setPage(newTotalPages);
            }
        } catch (err) {
            console.error("Error deleting task:", err);
            setError("Failed to delete task");
        }
    };

    // Delete All
    const handleDeleteAll = async () => {
        try {
            await axios.delete(
                "http://localhost:5000/api/tasks"
            );

            setTasks([]);
            setPage(1);
            setModal(null);
        } catch (err) {
            console.error("Error deleting all tasks:", err);
            setError("Failed to delete all tasks");
        }
    };

    // View Task
    const handleViewTask = (taskId) => {
        navigate(`/task/${taskId}`);
        setModal(null);
    };

    return (
        <div className="min-h-screen bg-[#0d0f16] px-8 py-10">
            {/* Modal */}
            {modal?.type === "one" && (
                <ConfirmModal
                    message="This task will be permanently removed. This action cannot be undone."
                    onConfirm={() =>
                        handleDeleteOne(modal.id)
                    }
                    onCancel={() => setModal(null)}
                />
            )}

            {modal?.type === "all" && (
                <ConfirmModal
                    message={`All ${tasks.length} tasks will be permanently deleted. This action cannot be undone.`}
                    onConfirm={handleDeleteAll}
                    onCancel={() => setModal(null)}
                />
            )}

            {/* Error */}
            {error && (
                <div className="mb-6 p-4 bg-red-500/10 border border-red-500/25 rounded-sm text-red-400 text-sm flex items-center gap-3">
                    {error}
                </div>
            )}

            {/* Header */}
            <div className="flex items-start justify-between mb-8">
                <div>
                    <div className="flex items-center gap-3 mb-2">
                        <div className="h-px w-6 bg-orange-500" />

                        <span className="text-orange-400 text-xs font-semibold tracking-[0.16em] uppercase">
                            Delivery Operations
                        </span>
                    </div>

                    <h1
                        className="text-white font-black leading-none tracking-tight mb-2"
                        style={{
                            fontSize: "2.1rem",
                            fontFamily: "'Georgia', serif",
                        }}
                    >
                        All Tasks
                    </h1>

                    <p className="text-white/40 text-sm">
                        Manage, monitor and control all delivery
                        assignments in one place.
                    </p>
                </div>

                {tasks.length > 0 && (
                    <button
                        onClick={() =>
                            setModal({ type: "all" })
                        }
                        className="flex items-center gap-2 px-4 py-2.5 text-sm font-semibold text-red-400 border border-red-500/25 bg-red-500/8 hover:bg-red-500/18 hover:border-red-400/40 rounded-sm transition-all duration-200 cursor-pointer mt-1"
                    >
                        <IconDeleteAll />
                        Delete All Tasks
                    </button>
                )}
            </div>

            {/* Table */}
            <div className="bg-[#13151e] border border-white/8 rounded-sm overflow-hidden">
                {loading ? (
                    <div className="flex flex-col items-center justify-center py-24 text-center">
                        <div className="w-12 h-12 border-2 border-orange-500/20 border-t-orange-500 rounded-full animate-spin mb-4" />

                        <p className="text-white/50 text-sm font-medium">
                            Loading tasks...
                        </p>
                    </div>
                ) : tasks.length === 0 ? (
                    <div className="flex flex-col items-center justify-center py-24 text-center">
                        <p className="text-white/30 text-sm font-medium">
                            No tasks found
                        </p>
                    </div>
                ) : (
                    <div className="overflow-x-auto">
                        <table className="w-full text-sm">
                            <thead>
                                <tr className="border-b border-white/8 bg-[#0f1117]">
                                    {[
                                        "#",
                                        "Task Title",
                                        "Rider Name",
                                        "Delivery Area",
                                        "Priority",
                                        "Status",
                                        "Actions",
                                    ].map((col) => (
                                        <th
                                            key={col}
                                            className={`px-5 py-3.5 text-left text-xs font-semibold tracking-widest uppercase text-white/35 whitespace-nowrap ${col === "Actions"
                                                    ? "text-center"
                                                    : ""
                                                }`}
                                        >
                                            {col}
                                        </th>
                                    ))}
                                </tr>
                            </thead>

                            <tbody>
                                {pageTasks.map((task, i) => (
                                    <tr
                                        key={task._id}
                                        className={`border-b border-white/5 transition-colors duration-150 hover:bg-white/[0.03] ${i % 2 === 0
                                                ? ""
                                                : "bg-white/[0.015]"
                                            }`}
                                    >
                                        {/* Number */}
                                        <td className="px-5 py-4 whitespace-nowrap">
                                            <span className="text-white/50 font-mono text-xs font-semibold">
                                                {startIdx + i + 1}
                                            </span>
                                        </td>

                                        {/* Title */}
                                        <td className="px-5 py-4 max-w-[220px]">
                                            <span className="text-white/85 font-medium leading-snug line-clamp-2 text-[13px]">
                                                {task.title}
                                            </span>
                                        </td>

                                        {/* Rider */}
                                        <td className="px-5 py-4 whitespace-nowrap">
                                            <div className="flex items-center gap-2.5">
                                                <div className="w-7 h-7 rounded-full bg-orange-500/20 border border-orange-500/30 flex items-center justify-center text-orange-300 text-[10px] font-bold flex-shrink-0">
                                                    {(task.rider || "")
                                                        .split(" ")
                                                        .map(
                                                            (n) =>
                                                                n[0]
                                                        )
                                                        .join("")
                                                        .slice(
                                                            0,
                                                            2
                                                        )}
                                                </div>

                                                <span className="text-white/70 text-[13px]">
                                                    {task.rider}
                                                </span>
                                            </div>
                                        </td>

                                        {/* Area */}
                                        <td className="px-5 py-4 whitespace-nowrap">
                                            <span className="text-white/50 text-[13px]">
                                                {task.area}
                                            </span>
                                        </td>

                                        {/* Priority */}
                                        <td className="px-5 py-4 whitespace-nowrap">
                                            <span
                                                className={`inline-flex items-center px-2.5 py-0.5 rounded-sm border text-[11px] font-semibold tracking-wide ${PRIORITY_STYLES[
                                                    task
                                                        .priority
                                                    ]
                                                    }`}
                                            >
                                                {task.priority}
                                            </span>
                                        </td>

                                        {/* Status */}
                                        <td className="px-5 py-4 whitespace-nowrap">
                                            <span
                                                className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-sm border text-[11px] font-semibold tracking-wide ${STATUS_STYLES[
                                                    task.status
                                                    ]
                                                    }`}
                                            >
                                                <span
                                                    className={`w-1.5 h-1.5 rounded-full ${STATUS_DOT[
                                                        task
                                                            .status
                                                        ]
                                                        }`}
                                                />

                                                {task.status}
                                            </span>
                                        </td>

                                        {/* Actions */}
                                        <td className="px-5 py-4">
                                            <div className="flex items-center justify-center gap-1">
                                                {/* View */}
                                                <button
                                                    title="View task"
                                                    onClick={() =>
                                                        handleViewTask(
                                                            task._id
                                                        )
                                                    }
                                                    className="w-8 h-8 rounded-sm flex items-center justify-center text-sky-400 bg-sky-400/8 border border-sky-400/20 hover:bg-sky-400/20 hover:border-sky-400/40 transition-all duration-150 cursor-pointer"
                                                >
                                                    <IconView />
                                                </button>

                                                {/* Edit */}
                                                <button
                                                    title="Edit task"
                                                    onClick={() => navigate(`/edit/${task._id}`)}
                                                    className="w-8 h-8 rounded-sm flex items-center justify-center text-amber-400 bg-amber-400/8 border border-amber-400/20 hover:bg-amber-400/20 hover:border-amber-400/40 transition-all duration-150 cursor-pointer"
                                                >
                                                    <IconEdit />
                                                </button>

                                                {/* Delete */}
                                                <button
                                                    title="Delete task"
                                                    onClick={() =>
                                                        setModal({
                                                            type: "one",
                                                            id: task._id,
                                                        })
                                                    }
                                                    className="w-8 h-8 rounded-sm flex items-center justify-center text-red-400 bg-red-400/8 border border-red-400/20 hover:bg-red-400/20 hover:border-red-400/40 transition-all duration-150 cursor-pointer"
                                                >
                                                    <IconDelete />
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}

                {/* Pagination */}
                {tasks.length > 0 && !loading && (
                    <div className="flex items-center justify-between px-5 py-3.5 border-t border-white/8 bg-[#0f1117]">
                        <p className="text-white/35 text-xs">
                            Showing{" "}
                            <span className="text-white/60 font-semibold">
                                {startIdx + 1}
                            </span>{" "}
                            to{" "}
                            <span className="text-white/60 font-semibold">
                                {endIdx}
                            </span>{" "}
                            of{" "}
                            <span className="text-white/60 font-semibold">
                                {tasks.length}
                            </span>{" "}
                            tasks
                        </p>

                        <div className="flex items-center gap-1">
                            <button
                                onClick={() =>
                                    setPage((p) =>
                                        Math.max(1, p - 1)
                                    )
                                }
                                disabled={safePage === 1}
                                className="w-8 h-8 flex items-center justify-center rounded-sm border border-white/10 text-white/40 hover:text-white hover:border-white/25 disabled:opacity-25 disabled:cursor-not-allowed transition-all cursor-pointer"
                            >
                                <IconChevronLeft />
                            </button>

                            {Array.from(
                                { length: totalPages },
                                (_, i) => i + 1
                            ).map((pg) => (
                                <button
                                    key={pg}
                                    onClick={() =>
                                        setPage(pg)
                                    }
                                    className={`w-8 h-8 flex items-center justify-center rounded-sm text-xs font-semibold border transition-all cursor-pointer ${pg === safePage
                                            ? "bg-orange-500 border-orange-500 text-white"
                                            : "border-white/10 text-white/40 hover:text-white hover:border-white/25"
                                        }`}
                                >
                                    {pg}
                                </button>
                            ))}

                            <button
                                onClick={() =>
                                    setPage((p) =>
                                        Math.min(
                                            totalPages,
                                            p + 1
                                        )
                                    )
                                }
                                disabled={
                                    safePage === totalPages
                                }
                                className="w-8 h-8 flex items-center justify-center rounded-sm border border-white/10 text-white/40 hover:text-white hover:border-white/25 disabled:opacity-25 disabled:cursor-not-allowed transition-all cursor-pointer"
                            >
                                <IconChevronRight />
                            </button>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};

export default TaskList;