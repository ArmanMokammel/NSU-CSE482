import React from 'react';
import axios from 'axios';
import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";

const TASK = {
    id: "DLV-0041",
    title: "Deliver fragile electronics to Gulshan branch",
    rider: "Karim Hossain",
    area: "Gulshan, Dhaka",
    priority: "High",
    status: "In Progress",
    createdAt: "2026-05-08T09:14:00",
    updatedAt: "2026-05-10T14:32:00",
};

const PRIORITY_STYLES = {
    High: { pill: "text-red-400 bg-red-400/10 border-red-400/25", dot: "bg-red-400" },
    Medium: { pill: "text-amber-400 bg-amber-400/10 border-amber-400/25", dot: "bg-amber-400" },
    Low: { pill: "text-emerald-400 bg-emerald-400/10 border-emerald-400/25", dot: "bg-emerald-400" },
};

const STATUS_STYLES = {
    "In Progress": { pill: "text-sky-400 bg-sky-400/10 border-sky-400/25", dot: "bg-sky-400" },
    Pending: { pill: "text-orange-400 bg-orange-400/10 border-orange-400/25", dot: "bg-orange-400" },
    Completed: { pill: "text-emerald-400 bg-emerald-400/10 border-emerald-400/25", dot: "bg-emerald-400" },
};

const fmt = (iso) =>
    new Date(iso).toLocaleString("en-GB", {
        day: "2-digit", month: "short", year: "numeric",
        hour: "2-digit", minute: "2-digit", hour12: true,
    });

// Icons
const IconBack = () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4">
        <polyline points="15 18 9 12 15 6" />
    </svg>
);
const IconEdit = () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.9} strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4">
        <path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7" />
        <path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z" />
    </svg>
);
const IconTaskBig = () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.3} strokeLinecap="round" strokeLinejoin="round" className="w-full h-full">
        <rect x="2" y="7" width="20" height="14" rx="2" />
        <path d="M16 7V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v2" />
        <line x1="12" y1="12" x2="12" y2="16" />
        <line x1="10" y1="14" x2="14" y2="14" />
    </svg>
);
const IconTitle = () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4">
        <polyline points="4 7 4 4 20 4 20 7" />
        <line x1="9" y1="20" x2="15" y2="20" />
        <line x1="12" y1="4" x2="12" y2="20" />
    </svg>
);
const IconRider = () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4">
        <circle cx="12" cy="7" r="4" />
        <path d="M5.5 21a8.5 8.5 0 0113 0" />
    </svg>
);
const IconArea = () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4">
        <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7z" />
        <circle cx="12" cy="9" r="2.5" />
    </svg>
);
const IconPriority = () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4">
        <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
    </svg>
);
const IconStatus = () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4">
        <circle cx="12" cy="12" r="9" />
        <polyline points="12 7 12 12 15.5 14" />
    </svg>
);
const IconCreatedAt = () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4">
        <rect x="3" y="4" width="18" height="18" rx="2" />
        <line x1="16" y1="2" x2="16" y2="6" />
        <line x1="8" y1="2" x2="8" y2="6" />
        <line x1="3" y1="10" x2="21" y2="10" />
        <line x1="8" y1="14" x2="8" y2="14" strokeWidth={2.5} strokeLinecap="round" />
        <line x1="12" y1="14" x2="12" y2="14" strokeWidth={2.5} strokeLinecap="round" />
    </svg>
);
const IconUpdatedAt = () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4">
        <polyline points="23 4 23 10 17 10" />
        <path d="M20.49 15a9 9 0 11-2.12-9.36L23 10" />
    </svg>
);

const ROWS = [
    { key: "title", label: "Task Title", icon: <IconTitle />, render: (v) => <span className="text-white/85 font-medium text-sm">{v}</span> },
    {
        key: "rider", label: "Rider Name", icon: <IconRider />,
        render: (v) => (
            <div className="flex items-center gap-2.5">
                <div className="w-7 h-7 rounded-full bg-orange-500/20 border border-orange-500/30 flex items-center justify-center text-orange-300 text-[10px] font-bold flex-shrink-0">
                    {v.split(" ").map((n) => n[0]).join("").slice(0, 2)}
                </div>
                <span className="text-white/85 text-sm font-medium">{v}</span>
            </div>
        ),
    },
    { key: "area", label: "Delivery Area", icon: <IconArea />, render: (v) => <span className="text-white/85 text-sm">{v}</span> },
    {
        key: "priority", label: "Priority", icon: <IconPriority />,
        render: (v) => (
            <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-sm border text-[11px] font-semibold tracking-wide ${PRIORITY_STYLES[v]?.pill}`}>
                <span className={`w-1.5 h-1.5 rounded-full ${PRIORITY_STYLES[v]?.dot}`} />
                {v}
            </span>
        ),
    },
    {
        key: "status", label: "Status", icon: <IconStatus />,
        render: (v) => (
            <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-sm border text-[11px] font-semibold tracking-wide ${STATUS_STYLES[v]?.pill}`}>
                <span className={`w-1.5 h-1.5 rounded-full animate-pulse ${STATUS_STYLES[v]?.dot}`} />
                {v}
            </span>
        ),
    },
    { key: "createdAt", label: "Created At", icon: <IconCreatedAt />, render: (v) => <span className="text-white/55 text-sm font-mono">{fmt(v)}</span> },
    { key: "updatedAt", label: "Updated At", icon: <IconUpdatedAt />, render: (v) => <span className="text-white/55 text-sm font-mono">{fmt(v)}</span> },
];

const TaskDetails = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const [task, setTask] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");

    useEffect(() => {
        fetchTaskDetails();
    }, [id]);

    const fetchTaskDetails = async () => {
        try {
            setLoading(true);
            const response = await axios.get(`http://localhost:5000/api/tasks/${id}`);
            setTask(response.data);
            setError("");
        } catch (err) {
            console.error("Error fetching task:", err);
            setError("Failed to load task details");
        } finally {
            setLoading(false);
        }
    };

    if (loading) {
        return (
            <div className="min-h-screen bg-[#0d0f16] flex items-center justify-center">
                <div className="text-center">
                    <div className="w-12 h-12 border-2 border-orange-500/20 border-t-orange-500 rounded-full animate-spin mx-auto mb-4" />
                    <p className="text-white/50 text-sm font-medium">Loading task details...</p>
                </div>
            </div>
        );
    }

    if (error || !task) {
        return (
            <div className="min-h-screen bg-[#0d0f16] flex items-center justify-center px-8">
                <div className="text-center max-w-sm">
                    <div className="w-16 h-16 bg-red-400/12 border border-red-400/25 rounded-sm flex items-center justify-center mx-auto mb-5 text-red-400">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} className="w-7 h-7">
                            <circle cx="12" cy="12" r="9" />
                            <line x1="12" y1="8" x2="12" y2="12" />
                            <line x1="12" y1="16" x2="12.01" y2="16" />
                        </svg>
                    </div>
                    <h2 className="text-white font-black text-lg mb-2" style={{ fontFamily: "'Georgia', serif" }}>Error</h2>
                    <p className="text-white/40 text-sm mb-6">{error || "Task not found"}</p>
                    <button
                        onClick={() => navigate("/tasks")}
                        className="flex items-center gap-2 mx-auto px-5 py-2.5 bg-orange-500 hover:bg-orange-400 text-white text-sm font-semibold rounded-sm transition-all cursor-pointer"
                    >
                        <IconBack /> Back to List
                    </button>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-[#0d0f16] px-8 py-10">

            {/* Top bar — back + edit */}
            <div className="flex items-center justify-between mb-12">
                <button 
                    onClick={() => navigate("/tasks")}
                    className="flex items-center gap-2 text-white/50 hover:text-white text-sm font-semibold border border-white/10 hover:border-white/25 px-4 py-2.5 rounded-sm transition-all duration-200 cursor-pointer group"
                >
                    <span className="transition-transform duration-200 group-hover:-translate-x-0.5">
                        <IconBack />
                    </span>
                    Back to List
                </button>

                <button className="flex items-center gap-2 text-amber-400 bg-amber-400/8 border border-amber-400/25 hover:bg-amber-400/18 hover:border-amber-400/45 px-4 py-2.5 rounded-sm text-sm font-semibold transition-all duration-200 cursor-pointer">
                    <IconEdit />
                    Edit Task
                </button>
            </div>

            {/* Centered heading block */}
            <div className="flex flex-col items-center text-center mb-10">
                {/* Large icon */}
                <div className="w-16 h-16 text-orange-500/70 mb-5">
                    <IconTaskBig />
                </div>

                {/* Task ID badge */}
                <span className="inline-flex items-center gap-2 mb-4 px-3 py-1 rounded-sm border border-orange-500/25 bg-orange-500/8 text-orange-400 text-xs font-mono font-semibold tracking-widest">
                    <span className="w-1.5 h-1.5 rounded-full bg-orange-400" />
                    {task._id}
                </span>

                <h1
                    className="text-white font-black leading-none tracking-tight mb-3"
                    style={{ fontSize: "2rem", fontFamily: "'Georgia', serif" }}
                >
                    Task Details
                </h1>
                <p className="text-white/38 text-sm max-w-xs leading-relaxed">
                    A complete overview of this delivery task — status, assignment, and timestamps.
                </p>

                {/* Separator */}
                <div className="flex items-center gap-2 mt-5">
                    <div className="h-px w-12 bg-orange-500/40" />
                    <div className="w-1.5 h-1.5 rounded-full bg-orange-500/60" />
                    <div className="h-px w-12 bg-orange-500/40" />
                </div>
            </div>

            {/* Detail card */}
            <div className="max-w-2xl mx-auto bg-[#13151e] border border-white/8 rounded-sm overflow-hidden">

                {/* Card header bar */}
                <div className="px-7 py-3.5 bg-[#0f1117] border-b border-white/8 flex items-center gap-3">
                    <div className="w-2 h-2 rounded-full bg-orange-500" />
                    <span className="text-white/40 text-xs font-semibold tracking-widest uppercase">Task Information</span>
                </div>

                {/* Rows */}
                <div className="divide-y divide-white/[0.055]">
                    {ROWS.map(({ key, label, icon, render }) => (
                        <div
                            key={key}
                            className="flex items-center gap-5 px-7 py-4 hover:bg-white/[0.025] transition-colors duration-150 group"
                        >
                            {/* Icon */}
                            <div className="w-8 h-8 rounded-sm bg-orange-500/8 border border-orange-500/18 group-hover:border-orange-500/35 group-hover:bg-orange-500/14 flex items-center justify-center text-orange-400/70 group-hover:text-orange-400 transition-all duration-200 flex-shrink-0">
                                {icon}
                            </div>

                            {/* Label */}
                            <span className="w-32 flex-shrink-0 text-white/35 text-xs font-semibold tracking-widest uppercase">
                                {label}
                            </span>

                            {/* Divider */}
                            <div className="w-px h-5 bg-white/8 flex-shrink-0" />

                            {/* Value */}
                            <div className="flex-1 min-w-0">
                                {render(task[key])}
                            </div>
                        </div>
                    ))}
                </div>
            </div>

        </div>
    );
};

export default TaskDetails;