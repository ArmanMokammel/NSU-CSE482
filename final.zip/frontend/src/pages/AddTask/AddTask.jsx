import React from 'react';
import axios from 'axios';
import { useState } from "react";

const PRIORITIES = ["High", "Medium", "Low"];
const STATUSES = ["Pending", "In Progress", "Completed"];

const IconTask = () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.4} strokeLinecap="round" strokeLinejoin="round" className="w-full h-full">
        <rect x="2" y="7" width="20" height="14" rx="2" />
        <path d="M16 7V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v2" />
        <line x1="12" y1="12" x2="12" y2="16" />
        <line x1="10" y1="14" x2="14" y2="14" />
    </svg>
);

const IconPlus = () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.2} strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4">
        <circle cx="12" cy="12" r="9" />
        <line x1="12" y1="8" x2="12" y2="16" />
        <line x1="8" y1="12" x2="16" y2="12" />
    </svg>
);

const IconCancel = () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4">
        <line x1="18" y1="6" x2="6" y2="18" />
        <line x1="6" y1="6" x2="18" y2="18" />
    </svg>
);

const IconTitle = () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4">
        <polyline points="4 7 4 4 20 4 20 7" />
        <line x1="9" y1="20" x2="15" y2="20" />
        <line x1="12" y1="4" x2="12" y2="20" />
    </svg>
);

const IconRider = () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4">
        <circle cx="12" cy="7" r="4" />
        <path d="M5.5 21a8.5 8.5 0 0113 0" />
    </svg>
);

const IconArea = () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4">
        <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7z" />
        <circle cx="12" cy="9" r="2.5" />
    </svg>
);

const IconPriority = () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4">
        <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
    </svg>
);

const IconStatus = () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4">
        <circle cx="12" cy="12" r="9" />
        <polyline points="12 7 12 12 15.5 14" />
    </svg>
);

const IconChevronDown = () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4">
        <polyline points="6 9 12 15 18 9" />
    </svg>
);

const PRIORITY_COLORS = {
    High: "text-red-400",
    Medium: "text-amber-400",
    Low: "text-emerald-400",
};

const STATUS_COLORS = {
    Pending: "text-orange-400",
    "In Progress": "text-sky-400",
    Completed: "text-emerald-400",
};

const STATUS_DOT = {
    Pending: "bg-orange-400",
    "In Progress": "bg-sky-400",
    Completed: "bg-emerald-400",
};

const FIELDS = [
    {
        key: "title",
        label: "Task Title",
        placeholder: "e.g. Deliver electronics to Gulshan branch",
        icon: <IconTitle />,
        type: "text",
    },
    {
        key: "rider",
        label: "Rider Name",
        placeholder: "e.g. Karim Hossain",
        icon: <IconRider />,
        type: "text",
    },
    {
        key: "area",
        label: "Delivery Area",
        placeholder: "e.g. Gulshan, Dhaka",
        icon: <IconArea />,
        type: "text",
    },
    {
        key: "priority",
        label: "Priority",
        placeholder: "Select priority level",
        icon: <IconPriority />,
        type: "select",
        options: PRIORITIES,
    },
    {
        key: "status",
        label: "Status",
        placeholder: "Select task status",
        icon: <IconStatus />,
        type: "select",
        options: STATUSES,
    },
];

const AddTask = () => {
    const [form, setForm] = useState({ title: "", rider: "", area: "", priority: "", status: "" });
    const [errors, setErrors] = useState({});
    const [submitted, setSubmitted] = useState(false);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState("");

    const validate = () => {
        const e = {};
        if (!form.title.trim()) e.title = "Task title is required.";
        if (!form.rider.trim()) e.rider = "Rider name is required.";
        if (!form.area.trim()) e.area = "Delivery area is required.";
        if (!form.priority) e.priority = "Please select a priority.";
        if (!form.status) e.status = "Please select a status.";
        return e;
    };

    const handleSubmit = async () => {
        const e = validate();
        setErrors(e);
        if (Object.keys(e).length === 0) {
            setLoading(true);
            setError("");
            try {
                await axios.post("http://localhost:5000/api/tasks", {
                    title: form.title,
                    rider: form.rider,
                    area: form.area,
                    priority: form.priority,
                    status: form.status,
                });
                setSubmitted(true);
            } catch (err) {
                setError(err.response?.data?.error || err.message || "An error occurred. Please try again.");
                console.error("Error:", err);
            } finally {
                setLoading(false);
            }
        }
    };

    const handleReset = () => {
        setForm({ title: "", rider: "", area: "", priority: "", status: "" });
        setErrors({});
        setSubmitted(false);
        setError("");
    };

    if (submitted) {
        return (
            <div className="min-h-screen bg-[#0d0f16] flex items-center justify-center px-8 py-16">
                <div className="text-center max-w-sm">
                    <div className="w-16 h-16 bg-emerald-400/12 border border-emerald-400/25 rounded-sm flex items-center justify-center mx-auto mb-5 text-emerald-400">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" className="w-7 h-7">
                            <path d="M22 11.08V12a10 10 0 11-5.93-9.14" />
                            <polyline points="22 4 12 14.01 9 11.01" />
                        </svg>
                    </div>
                    <h2 className="text-white font-black text-xl mb-2" style={{ fontFamily: "'Georgia', serif" }}>Task Created!</h2>
                    <p className="text-white/40 text-sm mb-6">Your delivery task has been successfully added to the system.</p>
                    <div className="bg-[#13151e] border border-white/8 rounded-sm p-4 text-left mb-6 space-y-2">
                        {[
                            { label: "Title", value: form.title },
                            { label: "Rider", value: form.rider },
                            { label: "Area", value: form.area },
                            { label: "Priority", value: form.priority },
                            { label: "Status", value: form.status },
                        ].map(({ label, value }) => (
                            <div key={label} className="flex justify-between text-xs">
                                <span className="text-white/35 uppercase tracking-wider font-semibold">{label}</span>
                                <span className="text-white/70">{value}</span>
                            </div>
                        ))}
                    </div>
                    <button
                        onClick={handleReset}
                        className="flex items-center gap-2 mx-auto px-5 py-2.5 bg-orange-500 hover:bg-orange-400 text-white text-sm font-semibold rounded-sm transition-all cursor-pointer"
                    >
                        <IconPlus /> Add Another Task
                    </button>
                </div>
            </div>
        );
    }

    if (error) {
        return (
            <div className="min-h-screen bg-[#0d0f16] flex items-center justify-center px-8 py-16">
                <div className="text-center max-w-sm">
                    <div className="w-16 h-16 bg-red-400/12 border border-red-400/25 rounded-sm flex items-center justify-center mx-auto mb-5 text-red-400">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" className="w-7 h-7">
                            <circle cx="12" cy="12" r="9" />
                            <line x1="12" y1="8" x2="12" y2="12" />
                            <line x1="12" y1="16" x2="12.01" y2="16" />
                        </svg>
                    </div>
                    <h2 className="text-white font-black text-xl mb-2" style={{ fontFamily: "'Georgia', serif" }}>Error!</h2>
                    <p className="text-white/40 text-sm mb-6">{error}</p>
                    <button
                        onClick={handleReset}
                        className="flex items-center gap-2 mx-auto px-5 py-2.5 bg-orange-500 hover:bg-orange-400 text-white text-sm font-semibold rounded-sm transition-all cursor-pointer"
                    >
                        <IconCancel /> Try Again
                    </button>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-[#0d0f16] px-8 py-10">
            {/* Page Header */}
            <div className="mb-10">
                <div className="flex items-center gap-3 mb-2">
                    <div className="h-px w-6 bg-orange-500" />
                    <span className="text-orange-400 text-xs font-semibold tracking-[0.16em] uppercase">
                        Delivery Operations
                    </span>
                </div>
                <h1
                    className="text-white font-black leading-none tracking-tight mb-2"
                    style={{ fontSize: "2.1rem", fontFamily: "'Georgia', serif" }}
                >
                    Add New Task
                </h1>
                <p className="text-white/40 text-sm">
                    Fill in the details below to assign a new delivery task to a rider.
                </p>
            </div>

            {/* Two-column layout */}
            <div className="flex gap-10 items-start max-w-5xl">

                {/* Left — Decorative Panel */}
                <div className="w-64 flex-shrink-0 sticky top-24">
                    <div className="bg-[#13151e] border border-white/8 rounded-sm p-6 flex flex-col items-center text-center">
                        {/* Large icon */}
                        <div className="w-24 h-24 text-orange-500/60 mb-5">
                            <IconTask />
                        </div>
                        <h3 className="text-white/80 font-semibold text-sm mb-2">New Delivery Task</h3>
                        <p className="text-white/35 text-xs leading-relaxed mb-6">
                            Assign riders, set priority levels and track every delivery from start to completion.
                        </p>

                        {/* Mini checklist */}
                        <div className="w-full space-y-2.5 text-left">
                            {[
                                "Set task title & description",
                                "Assign to a rider",
                                "Define delivery zone",
                                "Choose priority & status",
                            ].map((item, i) => (
                                <div key={i} className="flex items-start gap-2.5">
                                    <div className="w-4 h-4 rounded-sm bg-orange-500/15 border border-orange-500/30 flex items-center justify-center flex-shrink-0 mt-0.5">
                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round" className="w-2.5 h-2.5 text-orange-400">
                                            <polyline points="20 6 9 17 4 12" />
                                        </svg>
                                    </div>
                                    <span className="text-white/40 text-xs leading-snug">{item}</span>
                                </div>
                            ))}
                        </div>

                        {/* Divider */}
                        <div className="w-full h-px bg-white/6 my-5" />

                        {/* Stat pills */}
                        <div className="w-full grid grid-cols-2 gap-2">
                            <div className="bg-[#0f1117] border border-white/6 rounded-sm p-2 text-center">
                                <p className="text-orange-400 font-black text-lg leading-none">47</p>
                                <p className="text-white/30 text-[10px] mt-1 uppercase tracking-wider">Active</p>
                            </div>
                            <div className="bg-[#0f1117] border border-white/6 rounded-sm p-2 text-center">
                                <p className="text-emerald-400 font-black text-lg leading-none">1,198</p>
                                <p className="text-white/30 text-[10px] mt-1 uppercase tracking-wider">Done</p>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Right — Form */}
                <div className="flex-1 min-w-0">
                    <div className="bg-[#13151e] border border-white/8 rounded-sm overflow-hidden">
                        {/* Form header bar */}
                        <div className="px-7 py-4 border-b border-white/8 bg-[#0f1117] flex items-center gap-3">
                            <div className="w-2 h-2 rounded-full bg-orange-500" />
                            <span className="text-white/50 text-xs font-semibold tracking-widest uppercase">Task Details</span>
                        </div>

                        <div className="px-7 py-7 space-y-6">
                            {FIELDS.map((field) => (
                                <div key={field.key}>
                                    {/* Label */}
                                    <label className="flex items-center gap-2 text-white/70 text-xs font-semibold tracking-widest uppercase mb-2.5">
                                        <span className="text-orange-400/70">{field.icon}</span>
                                        {field.label}
                                        <span className="text-red-400/60 text-sm leading-none">*</span>
                                    </label>

                                    {field.type === "text" ? (
                                        <div className="relative">
                                            <input
                                                type="text"
                                                value={form[field.key]}
                                                onChange={(e) => {
                                                    setForm((f) => ({ ...f, [field.key]: e.target.value }));
                                                    if (errors[field.key]) setErrors((er) => ({ ...er, [field.key]: "" }));
                                                }}
                                                placeholder={field.placeholder}
                                                className={`w-full bg-[#0f1117] border rounded-sm px-4 py-3 text-sm text-white/85 placeholder-white/20 outline-none transition-all duration-200
                          focus:border-orange-500/60 focus:bg-[#12141f]
                          ${errors[field.key] ? "border-red-500/50" : "border-white/10 hover:border-white/20"}`}
                                            />
                                        </div>
                                    ) : (
                                        <div className="relative">
                                            <select
                                                value={form[field.key]}
                                                onChange={(e) => {
                                                    setForm((f) => ({ ...f, [field.key]: e.target.value }));
                                                    if (errors[field.key]) setErrors((er) => ({ ...er, [field.key]: "" }));
                                                }}
                                                className={`w-full bg-[#0f1117] border rounded-sm px-4 py-3 text-sm outline-none appearance-none transition-all duration-200 cursor-pointer
                          focus:border-orange-500/60 focus:bg-[#12141f]
                          ${!form[field.key] ? "text-white/25" : (field.key === "priority" ? PRIORITY_COLORS[form[field.key]] : STATUS_COLORS[form[field.key]])}
                          ${errors[field.key] ? "border-red-500/50" : "border-white/10 hover:border-white/20"}`}
                                            >
                                                <option value="" disabled className="text-white/25 bg-[#13151e]">
                                                    {field.placeholder}
                                                </option>
                                                {field.options.map((opt) => (
                                                    <option key={opt} value={opt} className="text-white bg-[#13151e]">
                                                        {opt}
                                                    </option>
                                                ))}
                                            </select>
                                            <div className="absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none text-white/25">
                                                <IconChevronDown />
                                            </div>
                                            {/* Status dot preview */}
                                            {field.key === "status" && form.status && (
                                                <div className={`absolute left-3.5 top-1/2 -translate-y-1/2 w-2 h-2 rounded-full ${STATUS_DOT[form.status]} pointer-events-none`}
                                                    style={{ left: "1rem" }}
                                                />
                                            )}
                                        </div>
                                    )}

                                    {/* Error */}
                                    {errors[field.key] && (
                                        <p className="mt-1.5 text-red-400 text-xs flex items-center gap-1.5">
                                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} className="w-3 h-3 flex-shrink-0">
                                                <circle cx="12" cy="12" r="9" />
                                                <line x1="12" y1="8" x2="12" y2="12" />
                                                <line x1="12" y1="16" x2="12.01" y2="16" />
                                            </svg>
                                            {errors[field.key]}
                                        </p>
                                    )}
                                </div>
                            ))}
                        </div>

                        {/* Form footer with buttons */}
                        <div className="px-7 py-5 border-t border-white/8 bg-[#0f1117] flex items-center gap-3">
                            <button
                                onClick={handleSubmit}
                                disabled={loading}
                                className="flex items-center gap-2 px-6 py-2.5 bg-orange-500 hover:bg-orange-400 disabled:bg-orange-500/50 disabled:cursor-not-allowed text-white text-sm font-semibold rounded-sm transition-all duration-200 cursor-pointer"
                            >
                                {loading ? (
                                    <>
                                        <svg className="w-4 h-4 animate-spin" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
                                            <circle cx="12" cy="12" r="10" opacity="0.25" />
                                            <path d="M4 12a8 8 0 0116 0" />
                                        </svg>
                                        Creating...
                                    </>
                                ) : (
                                    <>
                                        <IconPlus />
                                        Create Task
                                    </>
                                )}
                            </button>
                            <button
                                onClick={handleReset}
                                disabled={loading}
                                className="flex items-center gap-2 px-5 py-2.5 border border-white/12 hover:border-white/25 disabled:border-white/8 disabled:cursor-not-allowed text-white/55 hover:text-white/80 disabled:text-white/35 text-sm font-semibold rounded-sm transition-all duration-200 cursor-pointer"
                            >
                                <IconCancel />
                                Cancel
                            </button>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    );
};

export default AddTask;