import React, { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate, useParams } from "react-router-dom";

const PRIORITIES = ["High", "Medium", "Low"];
const STATUSES = ["Pending", "In Progress", "Completed"];

const PRIORITY_COLORS = {
    High: "text-red-400",
    Medium: "text-amber-400",
    Low: "text-emerald-400",
};

const STATUS_COLORS = {
    Pending: "text-orange-400",
    "In Progress": "text-sky-400",
    Completed: "text-emerald-400",
};

const STATUS_DOT = {
    Pending: "bg-orange-400",
    "In Progress": "bg-sky-400",
    Completed: "bg-emerald-400",
};

// Icons
const IconPlus = () => (
    <svg
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth={2.2}
        strokeLinecap="round"
        strokeLinejoin="round"
        className="w-4 h-4"
    >
        <circle cx="12" cy="12" r="9" />
        <line x1="12" y1="8" x2="12" y2="16" />
        <line x1="8" y1="12" x2="16" y2="12" />
    </svg>
);

const IconCancel = () => (
    <svg
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth={2}
        strokeLinecap="round"
        strokeLinejoin="round"
        className="w-4 h-4"
    >
        <line x1="18" y1="6" x2="6" y2="18" />
        <line x1="6" y1="6" x2="18" y2="18" />
    </svg>
);

const IconChevronDown = () => (
    <svg
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth={2}
        strokeLinecap="round"
        strokeLinejoin="round"
        className="w-4 h-4"
    >
        <polyline points="6 9 12 15 18 9" />
    </svg>
);

const EditTask = () => {
    const { id } = useParams();
    const navigate = useNavigate();

    const [form, setForm] = useState({
        title: "",
        rider: "",
        area: "",
        priority: "",
        status: "",
    });

    const [errors, setErrors] = useState({});
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [success, setSuccess] = useState(false);
    const [error, setError] = useState("");

    // Fetch Existing Task
    useEffect(() => {
        fetchTask();
    }, []);

    const fetchTask = async () => {
        try {
            setLoading(true);

            const response = await axios.get(
                `http://localhost:5000/api/tasks/${id}`
            );

            setForm({
                title: response.data.title || "",
                rider: response.data.rider || "",
                area: response.data.area || "",
                priority: response.data.priority || "",
                status: response.data.status || "",
            });
        } catch (err) {
            console.error(err);
            setError("Failed to load task.");
        } finally {
            setLoading(false);
        }
    };

    const validate = () => {
        const e = {};

        if (!form.title.trim()) {
            e.title = "Task title is required.";
        }

        if (!form.rider.trim()) {
            e.rider = "Rider name is required.";
        }

        if (!form.area.trim()) {
            e.area = "Delivery area is required.";
        }

        if (!form.priority) {
            e.priority = "Please select priority.";
        }

        if (!form.status) {
            e.status = "Please select status.";
        }

        return e;
    };

    const handleSubmit = async () => {
        const e = validate();

        setErrors(e);

        if (Object.keys(e).length > 0) return;

        try {
            setSaving(true);
            setError("");

            await axios.put(
                `http://localhost:5000/api/tasks/${id}`,
                form
            );

            setSuccess(true);

            setTimeout(() => {
                navigate("/tasks");
            }, 1500);
        } catch (err) {
            console.error(err);

            setError(
                err.response?.data?.error ||
                    "Failed to update task."
            );
        } finally {
            setSaving(false);
        }
    };

    const handleChange = (key, value) => {
        setForm((prev) => ({
            ...prev,
            [key]: value,
        }));

        if (errors[key]) {
            setErrors((prev) => ({
                ...prev,
                [key]: "",
            }));
        }
    };

    if (loading) {
        return (
            <div className="min-h-screen bg-[#0d0f16] flex items-center justify-center">
                <div className="text-center">
                    <div className="w-12 h-12 border-2 border-orange-500/20 border-t-orange-500 rounded-full animate-spin mx-auto mb-4" />

                    <p className="text-white/50 text-sm">
                        Loading task...
                    </p>
                </div>
            </div>
        );
    }

    if (success) {
        return (
            <div className="min-h-screen bg-[#0d0f16] flex items-center justify-center px-8">
                <div className="text-center max-w-sm">
                    <div className="w-16 h-16 bg-emerald-400/12 border border-emerald-400/25 rounded-sm flex items-center justify-center mx-auto mb-5 text-emerald-400">
                        <svg
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth={2}
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            className="w-7 h-7"
                        >
                            <path d="M22 11.08V12a10 10 0 11-5.93-9.14" />
                            <polyline points="22 4 12 14.01 9 11.01" />
                        </svg>
                    </div>

                    <h2
                        className="text-white font-black text-xl mb-2"
                        style={{
                            fontFamily: "'Georgia', serif",
                        }}
                    >
                        Task Updated!
                    </h2>

                    <p className="text-white/40 text-sm">
                        Redirecting to task list...
                    </p>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-[#0d0f16] px-8 py-10">
            {/* Header */}
            <div className="mb-10">
                <div className="flex items-center gap-3 mb-2">
                    <div className="h-px w-6 bg-orange-500" />

                    <span className="text-orange-400 text-xs font-semibold tracking-[0.16em] uppercase">
                        Delivery Operations
                    </span>
                </div>

                <h1
                    className="text-white font-black leading-none tracking-tight mb-2"
                    style={{
                        fontSize: "2.1rem",
                        fontFamily: "'Georgia', serif",
                    }}
                >
                    Edit Task
                </h1>

                <p className="text-white/40 text-sm">
                    Update delivery task information.
                </p>
            </div>

            {/* Error */}
            {error && (
                <div className="mb-6 p-4 bg-red-500/10 border border-red-500/25 rounded-sm text-red-400 text-sm">
                    {error}
                </div>
            )}

            {/* Form */}
            <div className="max-w-3xl">
                <div className="bg-[#13151e] border border-white/8 rounded-sm overflow-hidden">
                    {/* Header */}
                    <div className="px-7 py-4 border-b border-white/8 bg-[#0f1117]">
                        <span className="text-white/50 text-xs font-semibold tracking-widest uppercase">
                            Task Details
                        </span>
                    </div>

                    {/* Body */}
                    <div className="p-7 space-y-6">
                        {/* Title */}
                        <div>
                            <label className="block text-white/70 text-xs font-semibold tracking-widest uppercase mb-2">
                                Task Title
                            </label>

                            <input
                                type="text"
                                value={form.title}
                                onChange={(e) =>
                                    handleChange(
                                        "title",
                                        e.target.value
                                    )
                                }
                                className={`w-full bg-[#0f1117] border rounded-sm px-4 py-3 text-sm text-white outline-none transition-all
                                ${
                                    errors.title
                                        ? "border-red-500/50"
                                        : "border-white/10 focus:border-orange-500/60"
                                }`}
                                placeholder="Enter task title"
                            />

                            {errors.title && (
                                <p className="text-red-400 text-xs mt-2">
                                    {errors.title}
                                </p>
                            )}
                        </div>

                        {/* Rider */}
                        <div>
                            <label className="block text-white/70 text-xs font-semibold tracking-widest uppercase mb-2">
                                Rider Name
                            </label>

                            <input
                                type="text"
                                value={form.rider}
                                onChange={(e) =>
                                    handleChange(
                                        "rider",
                                        e.target.value
                                    )
                                }
                                className={`w-full bg-[#0f1117] border rounded-sm px-4 py-3 text-sm text-white outline-none transition-all
                                ${
                                    errors.rider
                                        ? "border-red-500/50"
                                        : "border-white/10 focus:border-orange-500/60"
                                }`}
                                placeholder="Enter rider name"
                            />

                            {errors.rider && (
                                <p className="text-red-400 text-xs mt-2">
                                    {errors.rider}
                                </p>
                            )}
                        </div>

                        {/* Area */}
                        <div>
                            <label className="block text-white/70 text-xs font-semibold tracking-widest uppercase mb-2">
                                Delivery Area
                            </label>

                            <input
                                type="text"
                                value={form.area}
                                onChange={(e) =>
                                    handleChange(
                                        "area",
                                        e.target.value
                                    )
                                }
                                className={`w-full bg-[#0f1117] border rounded-sm px-4 py-3 text-sm text-white outline-none transition-all
                                ${
                                    errors.area
                                        ? "border-red-500/50"
                                        : "border-white/10 focus:border-orange-500/60"
                                }`}
                                placeholder="Enter delivery area"
                            />

                            {errors.area && (
                                <p className="text-red-400 text-xs mt-2">
                                    {errors.area}
                                </p>
                            )}
                        </div>

                        {/* Priority */}
                        <div>
                            <label className="block text-white/70 text-xs font-semibold tracking-widest uppercase mb-2">
                                Priority
                            </label>

                            <div className="relative">
                                <select
                                    value={form.priority}
                                    onChange={(e) =>
                                        handleChange(
                                            "priority",
                                            e.target.value
                                        )
                                    }
                                    className={`w-full appearance-none bg-[#0f1117] border rounded-sm px-4 py-3 text-sm outline-none transition-all
                                    ${
                                        form.priority
                                            ? PRIORITY_COLORS[
                                                  form.priority
                                              ]
                                            : "text-white/25"
                                    }
                                    ${
                                        errors.priority
                                            ? "border-red-500/50"
                                            : "border-white/10 focus:border-orange-500/60"
                                    }`}
                                >
                                    <option value="">
                                        Select priority
                                    </option>

                                    {PRIORITIES.map((p) => (
                                        <option
                                            key={p}
                                            value={p}
                                            className="text-white bg-[#13151e]"
                                        >
                                            {p}
                                        </option>
                                    ))}
                                </select>

                                <div className="absolute right-3 top-1/2 -translate-y-1/2 text-white/30 pointer-events-none">
                                    <IconChevronDown />
                                </div>
                            </div>

                            {errors.priority && (
                                <p className="text-red-400 text-xs mt-2">
                                    {errors.priority}
                                </p>
                            )}
                        </div>

                        {/* Status */}
                        <div>
                            <label className="block text-white/70 text-xs font-semibold tracking-widest uppercase mb-2">
                                Status
                            </label>

                            <div className="relative">
                                <select
                                    value={form.status}
                                    onChange={(e) =>
                                        handleChange(
                                            "status",
                                            e.target.value
                                        )
                                    }
                                    className={`w-full appearance-none bg-[#0f1117] border rounded-sm px-4 py-3 text-sm outline-none transition-all
                                    ${
                                        form.status
                                            ? STATUS_COLORS[
                                                  form.status
                                              ]
                                            : "text-white/25"
                                    }
                                    ${
                                        errors.status
                                            ? "border-red-500/50"
                                            : "border-white/10 focus:border-orange-500/60"
                                    }`}
                                >
                                    <option value="">
                                        Select status
                                    </option>

                                    {STATUSES.map((s) => (
                                        <option
                                            key={s}
                                            value={s}
                                            className="text-white bg-[#13151e]"
                                        >
                                            {s}
                                        </option>
                                    ))}
                                </select>

                                <div className="absolute right-3 top-1/2 -translate-y-1/2 text-white/30 pointer-events-none">
                                    <IconChevronDown />
                                </div>

                                {form.status && (
                                    <div
                                        className={`absolute left-4 top-1/2 -translate-y-1/2 w-2 h-2 rounded-full ${STATUS_DOT[form.status]}`}
                                    />
                                )}
                            </div>

                            {errors.status && (
                                <p className="text-red-400 text-xs mt-2">
                                    {errors.status}
                                </p>
                            )}
                        </div>
                    </div>

                    {/* Footer */}
                    <div className="px-7 py-5 border-t border-white/8 bg-[#0f1117] flex items-center gap-3">
                        <button
                            onClick={handleSubmit}
                            disabled={saving}
                            className="flex items-center gap-2 px-6 py-2.5 bg-orange-500 hover:bg-orange-400 disabled:bg-orange-500/50 text-white text-sm font-semibold rounded-sm transition-all"
                        >
                            {saving ? (
                                <>
                                    <svg
                                        className="w-4 h-4 animate-spin"
                                        viewBox="0 0 24 24"
                                        fill="none"
                                        stroke="currentColor"
                                        strokeWidth={2}
                                    >
                                        <circle
                                            cx="12"
                                            cy="12"
                                            r="10"
                                            opacity="0.25"
                                        />

                                        <path d="M4 12a8 8 0 0116 0" />
                                    </svg>

                                    Saving...
                                </>
                            ) : (
                                <>
                                    <IconPlus />
                                    Update Task
                                </>
                            )}
                        </button>

                        <button
                            onClick={() => navigate("/tasks")}
                            className="flex items-center gap-2 px-5 py-2.5 border border-white/12 hover:border-white/25 text-white/55 hover:text-white/80 text-sm font-semibold rounded-sm transition-all"
                        >
                            <IconCancel />
                            Cancel
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default EditTask;