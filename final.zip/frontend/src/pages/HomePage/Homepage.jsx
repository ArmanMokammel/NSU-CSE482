import { useNavigate } from "react-router-dom";

const STATS = [
  {
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" className="w-7 h-7">
        <rect x="2" y="7" width="20" height="14" rx="2" />
        <path d="M16 7V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v2" />
        <line x1="12" y1="12" x2="12" y2="16" />
        <line x1="10" y1="14" x2="14" y2="14" />
      </svg>
    ),
    value: "1,284",
    label: "Total Tasks",
    sub: "All time records",
    accent: "text-orange-400",
    bg: "bg-orange-400/10",
    border: "border-orange-400/20",
  },
  {
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" className="w-7 h-7">
        <circle cx="12" cy="12" r="9" />
        <polyline points="12 7 12 12 15.5 14" />
      </svg>
    ),
    value: "47",
    label: "In Progress",
    sub: "Currently active",
    accent: "text-amber-400",
    bg: "bg-amber-400/10",
    border: "border-amber-400/20",
  },
  {
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" className="w-7 h-7">
        <path d="M22 11.08V12a10 10 0 11-5.93-9.14" />
        <polyline points="22 4 12 14.01 9 11.01" />
      </svg>
    ),
    value: "1,198",
    label: "Completed",
    sub: "Successfully done",
    accent: "text-emerald-400",
    bg: "bg-emerald-400/10",
    border: "border-emerald-400/20",
  },
  {
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" className="w-7 h-7">
        <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
      </svg>
    ),
    value: "98.2%",
    label: "Success Rate",
    sub: "Last 30 days",
    accent: "text-sky-400",
    bg: "bg-sky-400/10",
    border: "border-sky-400/20",
  },
];



function HeroSection() {
  const navigate = useNavigate();

  return (
    <div className="relative w-full overflow-hidden" style={{ minHeight: 520 }}>
      {/* Background */}
      <div className="absolute inset-0 bg-[#0f1117]">
        {/* Grid overlay */}
        <div
          className="absolute inset-0 opacity-[0.07]"
          style={{
            backgroundImage:
              "linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)",
            backgroundSize: "48px 48px",
          }}
        />

        {/* Large delivery truck silhouette */}
        <div className="absolute right-0 bottom-0 w-[55%] h-full flex items-end justify-end opacity-[0.06]">
          <svg viewBox="0 0 600 340" className="w-full" fill="white">
            <rect x="0" y="100" width="380" height="180" rx="8" />
            <rect x="380" y="140" width="170" height="140" rx="8" />
            <rect x="420" y="100" width="130" height="50" rx="4" />
            <circle cx="90" cy="295" r="45" />
            <circle cx="90" cy="295" r="25" />
            <circle cx="460" cy="295" r="45" />
            <circle cx="460" cy="295" r="25" />
            <rect x="150" y="120" width="180" height="100" rx="4" fill="none" stroke="white" strokeWidth="8" />
            <line x1="240" y1="120" x2="240" y2="220" stroke="white" strokeWidth="6" />
          </svg>
        </div>

        {/* Orange accent glow */}
        <div
          className="absolute top-[-60px] left-[-60px] w-[400px] h-[400px] rounded-full"
          style={{
            background:
              "radial-gradient(circle, rgba(249,115,22,0.12) 0%, transparent 70%)",
          }}
        />
      </div>

      {/* Content */}
      <div
        className="relative z-10 h-full flex flex-col justify-center px-12 py-16"
        style={{ minHeight: 520 }}
      >
        {/* Badge */}
        <div className="flex items-center gap-2 mb-6">
          <div className="h-px w-8 bg-orange-500" />

          <span className="text-orange-400 text-xs font-semibold tracking-[0.18em] uppercase">
            Logistics Platform
          </span>
        </div>

        {/* Headline */}
        <h1
          className="text-white font-black leading-none mb-4 max-w-xl"
          style={{
            fontSize: "clamp(2.2rem, 4vw, 3.4rem)",
            fontFamily: "'Georgia', serif",
            letterSpacing: "-0.02em",
          }}
        >
          Delivery Task
          <br />
          <span className="text-orange-400">Management</span>
          <br />
          System
        </h1>

        {/* Separator */}
        <div className="flex items-center gap-3 mb-5">
          <div className="h-0.5 w-10 bg-orange-500" />
          <div className="h-0.5 w-4 bg-orange-500/40" />
          <div className="h-0.5 w-2 bg-orange-500/20" />
        </div>

        {/* Description */}
        <p className="text-white/55 text-base leading-relaxed max-w-sm mb-8 font-light">
          Streamline your courier operations — assign, track, and close delivery
          tasks with precision and speed. Built for teams on the move.
        </p>

        {/* Action Buttons */}
        <div className="flex items-center gap-3">
          {/* Add Task */}
          <button
            onClick={() => navigate("/add-task")}
            className="flex items-center gap-2.5 bg-orange-500 hover:bg-orange-400 text-white text-sm font-semibold px-6 py-3 rounded-sm transition-all duration-200 tracking-wide cursor-pointer"
          >
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth={2.2}
              strokeLinecap="round"
              strokeLinejoin="round"
              className="w-4 h-4"
            >
              <circle cx="12" cy="12" r="9" />
              <line x1="12" y1="8" x2="12" y2="16" />
              <line x1="8" y1="12" x2="16" y2="12" />
            </svg>

            Add New Task
          </button>

          {/* View Tasks */}
          <button
            onClick={() => navigate("/tasks")}
            className="flex items-center gap-2.5 border border-white/20 hover:border-white/40 text-white/80 hover:text-white text-sm font-semibold px-6 py-3 rounded-sm transition-all duration-200 tracking-wide cursor-pointer"
          >
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth={2}
              strokeLinecap="round"
              strokeLinejoin="round"
              className="w-4 h-4"
            >
              <rect x="3" y="5" width="18" height="14" rx="2" />
              <line x1="7" y1="9" x2="17" y2="9" />
              <line x1="7" y1="13" x2="13" y2="13" />
              <line x1="7" y1="17" x2="11" y2="17" />
            </svg>

            View All Tasks
          </button>
        </div>
      </div>
    </div>
  );
}

function StatsSection() {
  return (
    <div className="bg-[#13151e] border-t border-white/8 px-12 py-10">
      <div className="grid grid-cols-4 gap-0 divide-x divide-white/8">
        {STATS.map((stat, i) => (
          <div key={i} className="px-8 first:pl-0 last:pr-0 flex flex-col gap-3">
            {/* Icon */}
            <div className={`w-12 h-12 rounded-sm ${stat.bg} border ${stat.border} flex items-center justify-center ${stat.accent}`}>
              {stat.icon}
            </div>
            {/* Number */}
            <div>
              <p className="text-white text-3xl font-black tracking-tight leading-none">
                {stat.value}
              </p>
              <p className="text-white/70 text-sm font-semibold mt-1.5 tracking-wide">
                {stat.label}
              </p>
            </div>
            {/* Sub */}
            <p className="text-white/35 text-xs font-medium tracking-wide uppercase">
              {stat.sub}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function HomePage() {
  return (
    <div className="min-h-screen bg-[#0d0f16] font-sans">
      <HeroSection />
      <StatsSection />
    </div>
  );
}