require("dotenv").config();

const express = require("express");
const cors = require("cors");
// const admin = require("./firebaseAdmin");
const { MongoClient, ServerApiVersion, ObjectId } = require("mongodb");
const app = express();

app.use(cors());
app.use(express.json({ limit: '100mb' }));
app.use(express.urlencoded({ limit: '100mb', extended: true }));

const uri = `mongodb://${process.env.DB_USER}:${process.env.DB_PASS}@ac-uikagwn-shard-00-00.v2kjlhg.mongodb.net:27017,ac-uikagwn-shard-00-01.v2kjlhg.mongodb.net:27017,ac-uikagwn-shard-00-02.v2kjlhg.mongodb.net:27017/?ssl=true&replicaSet=atlas-yigrxl-shard-0&authSource=admin&appName=Cluster0`;

// Create a MongoClient with a MongoClientOptions object to set the Stable API version
const client = new MongoClient(uri, {
  serverApi: {
    version: ServerApiVersion.v1,
    strict: true,
    deprecationErrors: true,
  }
});

let taskCollection;

async function run() {
  // try {

  // } finally {
  //   // Ensures that the client will close when you finish/error
  //   await client.close();
  // }

  // Connect the client to the server	(optional starting in v4.7)
  await client.connect();
  // Send a ping to confirm a successful connection
  await client.db("admin").command({ ping: 1 });
  console.log("Pinged your deployment. You successfully connected to MongoDB!");

  const db = client.db("taskManagementDB");
  taskCollection = db.collection("tasks");
}
run().catch(console.dir);

// POST: Add a new task
app.post("/api/tasks", async (req, res) => {
  try {
    const { title, rider, area, priority, status } = req.body;

    // Validate required fields
    if (!title || !rider || !area || !priority || !status) {
      return res.status(400).json({ error: "All fields are required" });
    }

    const newTask = {
      title,
      rider,
      area,
      priority,
      status,
      createdAt: new Date(),
    };

    const result = await taskCollection.insertOne(newTask);
    res.status(201).json({ message: "Task added successfully", taskId: result.insertedId });
  } catch (error) {
    console.error("Error adding task:", error);
    res.status(500).json({ error: "Failed to add task" });
  }
});

// GET: Get all tasks
app.get("/api/tasks", async (req, res) => {
  try {
    const tasks = await taskCollection.find({}).toArray();
    res.status(200).json(tasks);
  } catch (error) {
    console.error("Error fetching tasks:", error);
    res.status(500).json({ error: "Failed to fetch tasks" });
  }
});

// GET: Get a single task by ID
app.get("/api/tasks/:id", async (req, res) => {
  try {
    const { id } = req.params;
    
    // Validate if id is a valid MongoDB ObjectId
    if (!ObjectId.isValid(id)) {
      return res.status(400).json({ error: "Invalid task ID" });
    }

    const task = await taskCollection.findOne({ _id: new ObjectId(id) });
    
    if (!task) {
      return res.status(404).json({ error: "Task not found" });
    }

    res.status(200).json(task);
  } catch (error) {
    console.error("Error fetching task:", error);
    res.status(500).json({ error: "Failed to fetch task" });
  }
});

// PUT: Update a single task by ID
app.put("/api/tasks/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const { title, rider, area, priority, status } = req.body;

    // Validate if id is a valid MongoDB ObjectId
    if (!ObjectId.isValid(id)) {
      return res.status(400).json({ error: "Invalid task ID" });
    }

    // Validate at least one field is provided
    if (!title && !rider && !area && !priority && !status) {
      return res.status(400).json({ error: "At least one field is required to update" });
    }

    const updateData = {};
    if (title) updateData.title = title;
    if (rider) updateData.rider = rider;
    if (area) updateData.area = area;
    if (priority) updateData.priority = priority;
    if (status) updateData.status = status;
    updateData.updatedAt = new Date();

    const result = await taskCollection.updateOne(
      { _id: new ObjectId(id) },
      { $set: updateData }
    );

    if (result.matchedCount === 0) {
      return res.status(404).json({ error: "Task not found" });
    }

    res.status(200).json({ message: "Task updated successfully" });
  } catch (error) {
    console.error("Error updating task:", error);
    res.status(500).json({ error: "Failed to update task" });
  }
});

// DELETE: Delete a single task by ID
app.delete("/api/tasks/:id", async (req, res) => {
  try {
    const { id } = req.params;

    // Validate if id is a valid MongoDB ObjectId
    if (!ObjectId.isValid(id)) {
      return res.status(400).json({ error: "Invalid task ID" });
    }

    const result = await taskCollection.deleteOne({ _id: new ObjectId(id) });

    if (result.deletedCount === 0) {
      return res.status(404).json({ error: "Task not found" });
    }

    res.status(200).json({ message: "Task deleted successfully" });
  } catch (error) {
    console.error("Error deleting task:", error);
    res.status(500).json({ error: "Failed to delete task" });
  }
});

// DELETE: Delete all tasks
app.delete("/api/tasks", async (req, res) => {
  try {
    const result = await taskCollection.deleteMany({});

    res.status(200).json({ message: `${result.deletedCount} tasks deleted successfully` });
  } catch (error) {
    console.error("Error deleting all tasks:", error);
    res.status(500).json({ error: "Failed to delete tasks" });
  }
});

app.listen(process.env.PORT, () => {
  console.log(`Server running on port ${process.env.PORT}`);
});